前端最基础的三件套
html
css
javascrip

参考课程
![[Pasted image 20260120143945.png]]